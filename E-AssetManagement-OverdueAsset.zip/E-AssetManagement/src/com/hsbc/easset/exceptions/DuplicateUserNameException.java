package com.hsbc.easset.exceptions;

public class DuplicateUserNameException extends Exception{
	
	public DuplicateUserNameException(String message)
	{
		super(message);
	}

}
