package com.hsbc.easset.exceptions;

public class InvalidTelephoneNumberException extends Exception{
	
	public InvalidTelephoneNumberException(String message)
	{
		super(message);
	}

}
